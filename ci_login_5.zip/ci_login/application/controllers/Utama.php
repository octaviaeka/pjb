<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Utama extends CI_Controller {

    // master
    public function master(){
        $data['title'] = 'Master EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        //semua
        // $this->load->model('model_user');
        // $semua = $this->model_user->getMaster(); // memanggil method getAll
        // $data['semua'] = $semua; // menampung di variable $data

        $data['master'] = $this->db->get('master_ebt')->result_array();

        $this->form_validation->set_rules('commisioning', 'Commisioning', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/master', $data);
        }else{
            $this->load->helper('date');
            $this->db->insert('master_ebt', [
                'nama_site_plant' => $this->input->post('nama_site_plant'),
                'site_id' => $this->input->post('site_id'),
                'commisioning' => $this->input->post('commisioning'),
                'alamat' => $this->input->post('alamat'),
                'time_zone' => $this->input->post('time_zone'),
                'kapasitas' => $this->input->post('kapasitas'),
                'foto' => $this->input->post('foto'),
                'nama_operator' => $this->input->post('nama_operator'),
                'telepon' => $this->input->post('telepon'),
                'email' => $this->input->post('email'),
                'kota' => $this->input->post('kota'),
                'lat_long' => $this->input->post('lat_long'),
                'status' => $this->input->post('status'),
                'date_created' => $this->input->post('date_created'),
                'date_modified' => $this->input->post('date_modified')
                ]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Master Added!</div>');
            redirect('utama/master');
        }
    }

    public function editMaster(){
        $data['title'] = 'edit Master EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['master'] = $this->db->get('master_ebt')->result_array();

        $this->form_validation->set_rules('commisioning', 'Commisioning', 'required');
        
        if($this->form_validation->run() == false ){
            $this->load->view('utama/editmaster', $data);
        }else{
            $id = $this->input->post('id');
            $nama_site_plant = $this->input->post('nama_site_plant');
            $site_id = $this->input->post('site_id');
            $commisioning = $this->input->post('commisioning');
            $alamat = $this->input->post('alamat');
            $time_zone = $this->input->post('time_zone');
            $kapasitas = $this->input->post('kapasitas');
            $foto = $this->input->post('foto');
            $nama_operator = $this->input->post('nama_operator');
            $telepon = $this->input->post('telepon');
            $email = $this->input->post('email');
            $kota = $this->input->post('kota');
            $lat_long = $this->input->post('lat_long');
            $status = $this->input->post('status');
            $date_created = $this->input->post('date_created');
            $date_modified = $this->input->post('date_modified');

            $this->db->set('nama_site_plant', $nama_site_plant);
            $this->db->set('site_id', $site_id);
            $this->db->set('commisioning', $commisioning);
            $this->db->set('alamat', $alamat);
            $this->db->set('time_zone', $time_zone);
            $this->db->set('kapasitas', $kapasitas);
            $this->db->set('foto', $foto);
            $this->db->set('nama_operator', $nama_operator);
            $this->db->set('telepon', $telepon);
            $this->db->set('email', $email);
            $this->db->set('kota', $kota);
            $this->db->set('lat_long', $lat_long);
            $this->db->set('status', $status);
            $this->db->set('date_modified', $date_modified);

            $this->db->where('id', $id);
            $this->db->where('date_created', $date_created);
            $this->db->update('master_ebt');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Master EBT has been changed</div>');
            redirect('utama/master');
        }
    }

    public function deleteMaster($id){
        $this->load->model('model_user');
        $this->model_user->deleteMaster($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Master EBT has been deleted</div>');
        redirect('utama/master');
    }

    //site
    public function site(){
        $data['title'] = 'Site';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $this->load->model('model_user');
        $site = $this->model_user->getSite(); // memanggil method getAll
        $data['site'] = $site; // menampung di variable $data
        $this->load->view('utama/site', $data);
    }

    public function editSite(){

    }

    public function deleteSite(){

    }
    
    //equipment
    public function equipment(){
        $data['title'] = 'Equipment';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $this->load->model('model_user');
        $equipment = $this->model_user->getEquipment(); // memanggil method getAll
        $data['equipment'] = $equipment; // menampung di variable $data
        $this->load->view('utama/equipment', $data);
    }
        
    public function editEquipment(){
        
    }
        
    public function deleteEquipment(){
        
    }

    public function syslog(){
        $data['title'] = 'System Logbook';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $this->load->model('model_user');
        $syslog = $this->model_user->getSyslog(); // memanggil method getAll
        $data['syslog'] = $syslog; // menampung di variable $data
        $this->load->view('utama/system_logbook', $data);
    }

    public function editSyslog(){

    }

    public function deleteSyslog(){

    }
}