<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_ebt extends CI_Controller {

    public function index(){
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        $data['role_edit'] = $this->db->get_where('user', ['role_edit' => $this->session->userdata('role_edit')])->row_array();

        echo 'Dashboard ebt' . $data['user']['username'];
        echo 'Dashboard ebt' . $data['role_edit']['role_edit'];
        $this->load->view('main/ebt');
    }
}