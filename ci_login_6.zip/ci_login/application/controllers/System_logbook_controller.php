<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class System_logbook_controller extends CI_Controller {
	
	public function add_logbook()
	{
		$data['title'] = 'System Logbook';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $data['syslog'] = $this->db->get('system_logbook')->result_array();
        
        $this->form_validation->set_rules('description', 'Description', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/system_logbook', $data);
        }else{
            $this->load->model('System_logbook_model');
            $this->System_logbook_model->add_logbook_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New System Logbook Added!</div>');
            redirect('system_logbook_controller/add_logbook');
        }

	}

    public function edit_logbook($id){
        $this->load->model('System_logbook_model');
        $data['title'] = 'edit System Logbook';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $where = array('id_logbook'=>$id);
        $data['edit']=$this->System_logbook_model->edit_master($where,'system_logbook')->result();
        $this->load->view('utama/editsyslog',$data);
    }

    public function updateSyslog(){

        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['syslog'] = $this->db->get('system_logbook')->result_array();

        $this->form_validation->set_rules('description', 'Description', 'required');

        if($this->form_validation->run() == true ){
            $this->load->model('System_logbook_model');
            $this->System_logbook_model->edit_logbook_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">System Logbook has been changed</div>');
            redirect('system_logbook_controller/add_logbook');
        }
    }

    public function delete_logbook($id){
        $this->load->model('System_logbook_model');
        $this->System_logbook_model->delete_logbook_m($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">System Logbook has been deleted</div>');
        redirect('system_logbook_controller/add_logbook');
    }
}