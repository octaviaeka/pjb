<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Configuration_controller extends CI_Controller {
    public function add_device()
    {
        $data['title'] = 'Equipment / Device';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $data['equipment'] = $this->db->get('m_tagname')->result_array();

        $this->form_validation->set_rules('description', 'Description', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/equipment', $data);
        }else{
            $this->load->model('Configuration_model');
            $this->Configuration_model->add_device_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Equipment Added!</div>');
            redirect('Configuration_controller/add_device');
        }
    }

    public function edit_device($equipment_id)
    {
        $this->load->model('Configuration_model');
        $data['title'] = 'edit Equipment EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $where = array('equipment_id'=>$equipment_id);
        $data['edit']=$this->Configuration_model->edit_master($where,'m_tagname')->result();
        $this->load->view('utama/editequipment', $data);
    }

    public function update_device()
    {
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['equipment'] = $this->db->get('m_tagname')->result_array();

        $this->form_validation->set_rules('description', 'Description', 'required');

        if($this->form_validation->run() == true ){
            $this->load->model('Configuration_model');
            $this->Configuration_model->edit_device_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Equipment has been changed</div>');
            redirect('System_monitoring_controller/view_system_monitoring');
        }
    }

    public function delete_device($id)
    {
        $this->load->model('Configuration_model');
        $this->Configuration_model->delete_device_m($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Equipment has been deleted</div>');
        redirect('System_monitoring_controller/view_system_monitoring');
    }

    public function add_formula()
    {
        $data['title'] = 'Formula Perhitungan';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $data['formula'] = $this->db->get('formula_perhitungan')->result_array();

        $this->form_validation->set_rules('nama_perhitungan', 'Nama_perhitungan', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/formula', $data);
        }else{
            $this->load->model('Configuration_model');
            $this->Configuration_model->add_formula_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Formula Added!</div>');
            redirect('Configuration_controller/add_formula');
        }
    }

    public function edit_formula($id)
    {
        $this->load->model('Configuration_model');
        $data['title'] = 'edit Formula Perhitungan';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $where = array('id_perhitungan'=>$id);
        $data['edit']=$this->Configuration_model->edit_master($where,'formula_perhitungan')->result();
        $this->load->view('utama/editformula', $data);
    }

    public function update_formula()
    {
        $data['title'] = 'edit Formula Perhitungan';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['formula'] = $this->db->get('formula_perhitungan')->result_array();

        $this->form_validation->set_rules('id_perhitungan', 'Id_perhitungan', 'required');

        if($this->form_validation->run() == true ){
            $this->load->model('Configuration_model');
            $this->Configuration_model->edit_formula_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Formula has been changed</div>');
            redirect('Configuration_controller/add_formula');
        }
    }

    public function delete_formula($id)
    {
        $this->load->model('Configuration_model');
        $this->Configuration_model->delete_formula_m($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Equipment has been deleted</div>');
        redirect('Configuration_controller/add_formula');
    }
}