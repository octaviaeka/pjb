<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_utama_controller extends CI_Controller {
    public function add_site(){
        $data['title'] = 'Site';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $data['site'] = $this->db->get('site')->result_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/site', $data);
        }else{
            $this->load->model('Dashboard_utama_model');
            $this->Dashboard_utama_model->add_site_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Site Added!</div>');
            redirect('utama/site');
        }
    }

    public function edit_site($id){
        $this->load->model('Dashboard_utama_model');
        $data['title'] = 'edit Site EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        $where = array('site_id'=>$id);
        $data['edit']=$this->Dashboard_utama_model->edit_master($where,'site')->result();
        $this->load->view('utama/editsite', $data);

    }

    public function update_site()
    {
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['site'] = $this->db->get('site')->result_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        if ($this->form_validation->run() == true){
            $this->load->model('Dashboard_utama_model');
            $this->Dashboard_utama_model->edit_site_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Site has been changed</div>');
            redirect('utama/site');
        }
    }

    public function delete_site($id){
        $this->load->model('Dashboard_utama_model');
        $this->Dashboard_utama_model->delete_site_m($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Site has been deleted</div>');
        redirect('utama/site');
    }

    public function add_unit_ebt(){
        $data['title'] = 'Master EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        
        $this->load->model('Dashboard_utama_model');
        $semua = $this->Dashboard_utama_model->getMaster(); // memanggil method getAll
        $data['semua'] = $semua; // menampung di variable $data

        $data['master'] = $this->db->get('master_ebt')->result_array();

        $this->form_validation->set_rules('commisioning', 'Commisioning', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/master', $data);
        }else{
            $this->load->helper('date');
            $this->Dashboard_utama_model->add_unit_ebt_m();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Master Added!</div>');
            redirect('utama/master');
        }
    }

    public function delete_unit_ebt($id){
        $this->load->model('Dashboard_utama_model');
        $this->Dashboard_utama_model->delete_unit_ebt_m($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Master EBT has been deleted</div>');
        redirect('utama/master');
    }

}