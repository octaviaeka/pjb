<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Utama extends CI_Controller {

    
    // public function editMaster($id){
    //     $data['title'] = 'edit Master EBT';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $this->form_validation->set_rules('commisioning', 'Commisioning', 'required');
    //     $this->load->model('model_user');
    //         $this->load->model('model_user');
    //         $where = array('id_master_ebt' => $id);
    //         $data['edit'] = $this->model_user->edit_master($where,'master_ebt')->result();
    //         $this->load->view('utama/editmaster',$data);
        
    // }

    // public function updatemaster()
    // {
    //     $data['title'] = 'edit Master EBT';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $this->form_validation->set_rules('commisioning', 'Commisioning', 'required');
    //     $this->load->model('model_user');

    //     if ($this->form_validation->run() == true) {
    //             $data['master'] = $this->db->get('master_ebt')->result_array();
    //             $id_master_ebt = $this->input->post('id_master_ebt');
    //             $nama_plant = $this->input->post('nama_plant');
    //             $site_id = $this->input->post('site_id');
    //             $commisioning = $this->input->post('commisioning');
    //             $alamat = $this->input->post('alamat');
    //             $time_zone = $this->input->post('time_zone');
    //             $kapasitas = $this->input->post('kapasitas');
    //             $foto = $this->input->post('foto');
    //             $nama_operator = $this->input->post('nama_operator');
    //             $telephone = $this->input->post('telephone');
    //             $email = $this->input->post('email');
    //             $kota = $this->input->post('kota');
    //             $latlong = $this->input->post('latlong');
    //             $status = $this->input->post('status');
    //             $date_created = $this->input->post('date_created');
    //             $date_modified = $this->input->post('date_modified');
    
    //             $this->db->set('id_master_ebt', $id_master_ebt);
    //             $this->db->set('nama_plant', $nama_plant);
    //             $this->db->set('site_id', $site_id);
    //             $this->db->set('commisioning', $commisioning);
    //             $this->db->set('alamat', $alamat);
    //             $this->db->set('time_zone', $time_zone);
    //             $this->db->set('kapasitas', $kapasitas);
    //             $this->db->set('foto', $foto);
    //             $this->db->set('nama_operator', $nama_operator);
    //             $this->db->set('telephone', $telephone);
    //             $this->db->set('email', $email);
    //             $this->db->set('kota', $kota);
    //             $this->db->set('latlong', $latlong);
    //             $this->db->set('status', $status);
    //             $this->db->set('date_created', $date_created);
    //             $this->db->set('date_modified', $date_modified);
    
    //             $this->db->where('id_master_ebt', $id_master_ebt);
    //             $this->db->where('date_created', $date_created);
    //             $this->db->update('master_ebt');
    //             $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Master EBT has been changed</div>');
    //             redirect('utama/master');
    //         }

    // }

    //site
    public function site(){
        $data['title'] = 'Site';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
        $data['site'] = $this->db->get('master_site')->result_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if($this->form_validation->run() == false ){
            $this->load->view('utama/site', $data);
        }else{
            // $this->db->insert('site', [
            //     'id_master_site' => $this->input->post('id_master_site'),
            //     'site_id' => $this->input->post('site_id'),
            //     'wilayah_kerja' => $this->input->post('wilayah_kerja'),
            //     'alamat' => $this->input->post('alamat'),
            //     'telephone' => $this->input->post('telephone'),
            //     'email' => $this->input->post('email'),
            //     'kota' => $this->input->post('kota'),
            //     'status' => $this->input->post('status'),
            //     'date_created' => $this->input->post('date_created')
            //     ]);
            $this->load->model('model_user');
            $this->model_user->insert_site();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Site Added!</div>');
            redirect('utama/site');
        }
    }

    public function edit_site($id){
        $this->load->model('model_user');
        $data['title'] = 'edit Site EBT';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        $where = array('site_id'=>$id);
        $data['edit']=$this->model_user->edit_master($where,'site')->result();
        $this->load->view('utama/editsite', $data);

    }

    public function update_site()
    {
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

        $data['site'] = $this->db->get('site')->result_array();

        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        if ($this->form_validation->run() == true){
            // $id = $this->input->post('site_id');
            // $id_master_site = $this->input->post('id_master_site');
            // $wilayah_kerja = $this->input->post('wilayah_kerja');
            // $alamat = $this->input->post('alamat');
            // $telephone = $this->input->post('telephone');
            // $email = $this->input->post('email');
            // $kota = $this->input->post('kota');
            // $status = $this->input->post('status');
            // $date_created = $this->input->post('date_created');
            // $date_modified = $this->input->post('date_modified');

            // $this->db->set('id_master_site', $id_master_site);
            // $this->db->set('wilayah_kerja', $wilayah_kerja);
            // $this->db->set('alamat', $alamat);
            // $this->db->set('telephone', $telephone);
            // $this->db->set('email', $email);
            // $this->db->set('kota', $kota);
            // $this->db->set('status', $status);
            // $this->db->set('date_modified', $date_modified);

            // $this->db->where('site_id', $id);
            // $this->db->where('date_created', $date_created);
            // $this->db->update('site');
            $this->load->model('model_user');
            $this->model_user->edit_site();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Site has been changed</div>');
            redirect('utama/site');
        }
    }

    public function delete_site($id){
        $this->load->model('model_user');
        $this->model_user->deleteSite($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Site has been deleted</div>');
        redirect('utama/site');
    }
    
    //equipment
    // public function equipment(){
    //     $data['title'] = 'Equipment';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
    //     $data['equipment'] = $this->db->get('equipment')->result_array();

    //     $this->form_validation->set_rules('description', 'Description', 'required');

    //     if($this->form_validation->run() == false ){
    //         $this->load->view('utama/equipment', $data);
    //     }else{
    //         $this->db->insert('equipment', [
    //             'site_id' => $this->input->post('site_id'),
    //             'plant_id' => $this->input->post('plant_id'),
    //             'tag_name' => $this->input->post('tag_name'),
    //             'description' => $this->input->post('description'),
    //             'lower_range' => $this->input->post('lower_range'),
    //             'upper_range' => $this->input->post('upper_range'),
    //             'unit' => $this->input->post('unit'),
    //             'posisi_kolom' => $this->input->post('posisi_kolom'),
    //             'date_created' => $this->input->post('date_created'),
    //             ]);
    //         $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Equipment Added!</div>');
    //         redirect('utama/equipment');
    //     }
    // }
        
    // public function editEquipment($id){
    //     $this->load->model('model_user');
    //     $data['title'] = 'edit Equipment EBT';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $where = array('id'=>$id);
    //     $data['edit']=$this->model_user->edit_master($where,'equipment')->result();
    //     $this->load->view('utama/editequipment', $data);
    // }

    // public function updateequipment(){
    //     $data['title'] = 'edit Equipment EBT';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $data['equipment'] = $this->db->get('equipment')->result_array();

    //     $this->form_validation->set_rules('description', 'Description', 'required');
    //     if($this->form_validation->run() == true ){
    //         $id = $this->input->post('id');
    //         $site_id = $this->input->post('site_id');
    //         $plant_id = $this->input->post('plant_id');
    //         $tag_name = $this->input->post('tag_name');
    //         $description = $this->input->post('description');
    //         $lower_range = $this->input->post('lower_range');
    //         $upper_range = $this->input->post('upper_range');
    //         $unit = $this->input->post('unit');
    //         $posisi_kolom = $this->input->post('posisi_kolom');
    //         $date_created = $this->input->post('date_modified');
    //         $date_modified = $this->input->post('date_modified');

    //         $this->db->set('site_id', $site_id);
    //         $this->db->set('plant_id', $plant_id);
    //         $this->db->set('tag_name', $tag_name);
    //         $this->db->set('description', $description);
    //         $this->db->set('lower_range', $lower_range);
    //         $this->db->set('upper_range', $upper_range);
    //         $this->db->set('unit', $unit);
    //         $this->db->set('posisi_kolom', $posisi_kolom);
    //         $this->db->set('date_created', $date_created);
    //         $this->db->set('date_modified', $date_modified);

    //         $this->db->where('id', $id);
    //         $this->db->where('date_created', $date_created);
    //         $this->db->update('equipment');
    //         $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Equipment has been changed</div>');
    //         redirect('utama/equipment');
    //     }
    // }
        
    // public function deleteEquipment($id){
    //     $this->load->model('model_user');
    //     $this->model_user->deleteEquipment($id);

    //     $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Equipment has been deleted</div>');
    //     redirect('utama/equipment');
    // }

    // public function syslog(){
    //     $data['title'] = 'System Logbook';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();
        
    //     $data['syslog'] = $this->db->get('system_logbook')->result_array();

    //     $this->form_validation->set_rules('description', 'Description', 'required');

    //     if($this->form_validation->run() == false ){
    //         $this->load->view('utama/system_logbook', $data);
    //     }else{
    //         $this->db->insert('system_logbook', [
    //             'type_alarm' => $this->input->post('type_alarm'),
    //             'time' => $this->input->post('time'),
    //             'equipment' => $this->input->post('equipment'),
    //             'description' => $this->input->post('description'),
    //             'sr' => $this->input->post('sr'),
    //             'wo' => $this->input->post('wo'),
    //             'date_created' => $this->input->post('date_created'),
    //             ]);
    //         $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New System Logbook Added!</div>');
    //         redirect('utama/syslog');
    //     }
    // }

    // public function editSyslog($id){
    //     $this->load->model('model_user');
    //     $data['title'] = 'edit System Logbook';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $where = array('id'=>$id);
    //     $data['edit']=$this->model_user->edit_master($where,'system_logbook')->result();
    //     $this->load->view('utama/editsyslog',$data);
    // }

    // public function updateSyslog(){
    //     $data['title'] = 'edit System Logbook';
    //     $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])->row_array();

    //     $data['syslog'] = $this->db->get('system_logbook')->result_array();

    //     $this->form_validation->set_rules('description', 'Description', 'required');
    //     if($this->form_validation->run() == true ){
    //         $id = $this->input->post('id');
    //         $type_alarm = $this->input->post('type_alarm');
    //         $time = $this->input->post('time');
    //         $equipment = $this->input->post('equipment');
    //         $description = $this->input->post('description');
    //         $sr = $this->input->post('sr');
    //         $wo = $this->input->post('wo');
    //         $date_created = $this->input->post('date_created');
    //         $date_modified = $this->input->post('date_modified');

    //         $this->db->set('type_alarm', $type_alarm);
    //         $this->db->set('time', $time);
    //         $this->db->set('equipment', $equipment);
    //         $this->db->set('description', $description);
    //         $this->db->set('sr', $sr);
    //         $this->db->set('wo', $wo);
    //         $this->db->set('date_modified', $date_modified);

    //         $this->db->where('id', $id);
    //         $this->db->where('date_created', $date_created);
    //         $this->db->update('system_logbook');
    //         $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">System Logbook has been changed</div>');
    //         redirect('utama/syslog');
    //     }
    // }

    // public function deleteSyslog($id){
    //     $this->load->model('model_user');
    //     $this->model_user->deleteSyslog($id);

    //     $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">System Logbook has been deleted</div>');
    //     redirect('utama/syslog');
    // }
}