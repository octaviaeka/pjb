<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Configuration_model extends CI_Model {
    public function add_device_m()
    {
        $this->db->insert('m_tagname', [
            'site_id' => $this->input->post('site_id'),
            'plant_id' => $this->input->post('plant_id'),
            'equipment_id' => $this->input->post('equipment_id'),
            'tag_name' => $this->input->post('tag_name'),
            'description' => $this->input->post('description'),
            'lower_range' => $this->input->post('lower_range'),
            'upper_range' => $this->input->post('upper_range'),
            'unit' => $this->input->post('unit'),
            'posisi_kolom' => $this->input->post('posisi_kolom'),
            'date_created' => $this->input->post('date_created'),
            ]);
    }

    public function edit_device_m()
    {
            $site_id = $this->input->post('site_id');
            $plant_id = $this->input->post('plant_id');
            $equipment_id = $this->input->post('equipment_id');
            $tag_name = $this->input->post('tag_name');
            $description = $this->input->post('description');
            $lower_range = $this->input->post('lower_range');
            $upper_range = $this->input->post('upper_range');
            $unit = $this->input->post('unit');
            $posisi_kolom = $this->input->post('posisi_kolom');
            $date_created = $this->input->post('date_created');
            $date_modified = $this->input->post('date_modified');

            $this->db->set('site_id', $site_id);
            $this->db->set('plant_id', $plant_id);
            $this->db->set('equipment_id', $equipment_id);
            $this->db->set('tag_name', $tag_name);
            $this->db->set('description', $description);
            $this->db->set('lower_range', $lower_range);
            $this->db->set('upper_range', $upper_range);
            $this->db->set('unit', $unit);
            $this->db->set('posisi_kolom', $posisi_kolom);
            $this->db->set('date_modified', $date_modified);

            $this->db->where('equipment_id', $equipment_id);
            $this->db->where('date_created', $date_created);
            $this->db->update('m_tagname');
    }

    function edit_master($where,$table){                              
        return $this->db->get_where($table,$where);
    }

    public function delete_device_m($id)
    {
        $this->db->delete('m_tagname', ['equipment_id' => $id]);
    }

    public function add_formula_m()
    {
        $this->db->insert('formula_perhitungan', [
            'id_perhitungan' => $this->input->post('id_perhitungan'),
            'plant_id' => $this->input->post('plant_id'),
            'jenis_perhitungan' => $this->input->post('jenis_perhitungan'),
            'nama_perhitungan' => $this->input->post('nama_perhitungan'),
            'query_perhitungan' => $this->input->post('query_perhitungan')
            ]);
    }

    public function edit_formula_m()
    {
            $id = $this->input->post('id_perhitungan');
            $plant_id = $this->input->post('plant_id');
            $jenis_perhitungan = $this->input->post('jenis_perhitungan');
            $nama_perhitungan = $this->input->post('nama_perhitungan');
            $query_perhitungan = $this->input->post('query_perhitungan');
            
            $this->db->set('plant_id', $plant_id);
            $this->db->set('jenis_perhitungan', $jenis_perhitungan);
            $this->db->set('nama_perhitungan', $nama_perhitungan);
            $this->db->set('query_perhitungan', $query_perhitungan);
    
            $this->db->where('id_perhitungan', $id);
            $this->db->update('formula_perhitungan');
    }

    public function delete_formula_m($id)
    {
        $this->db->delete('formula_perhitungan', ['id_perhitungan' => $id]);
    }
}