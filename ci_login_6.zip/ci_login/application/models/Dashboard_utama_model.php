<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_utama_model extends CI_Model {

    public function getRole($id){
        $id = $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('user'); 
        $role_view = $this->db->like('role_view','%$id%');
        $pisah = explode('#',$role_view);
        $jumlah = count($pisah);
        for ($i=0; $i <$jumlah ; $i++) { 
            echo $pisah[$i].'<br>';
        }
        return $this->db->get();
    }
    function edit_master($where,$table){                              
        return $this->db->get_where($table,$where);
    }

    function add_site_m(){
        $this->db->insert('master_site', [
            'id_master_site' => $this->input->post('id_master_site'),
            'site_id' => $this->input->post('site_id'),
            'wilayah_kerja' => $this->input->post('wilayah_kerja'),
            'alamat' => $this->input->post('alamat'),
            'telephone' => $this->input->post('telephone'),
            'email' => $this->input->post('email'),
            'kota' => $this->input->post('kota'),
            'status' => $this->input->post('status'),
            'date_created' => $this->input->post('date_created')
            ]);
    }

    function edit_site_m(){                              
            $id = $this->input->post('site_id');
            $id_master_site = $this->input->post('id_master_site');
            $wilayah_kerja = $this->input->post('wilayah_kerja');
            $alamat = $this->input->post('alamat');
            $telephone = $this->input->post('telephone');
            $email = $this->input->post('email');
            $kota = $this->input->post('kota');
            $status = $this->input->post('status');
            $date_created = $this->input->post('date_created');
            $date_modified = $this->input->post('date_modified');

            $this->db->set('id_master_site', $id_master_site);
            $this->db->set('wilayah_kerja', $wilayah_kerja);
            $this->db->set('alamat', $alamat);
            $this->db->set('telephone', $telephone);
            $this->db->set('email', $email);
            $this->db->set('kota', $kota);
            $this->db->set('status', $status);
            $this->db->set('date_modified', $date_modified);

            $this->db->where('site_id', $id);
            $this->db->where('date_created', $date_created);
            $this->db->update('master_site');
    }

    public function delete_site_m($id){
        $this->db->delete('master_site', ['site_id' => $id]);
    }

    public function getMaster(){
        $this->db->select('*');
        $this->db->from('master_ebt');
        $this->db->join('master_site', 'master_ebt.site_id=master_site.site_id');
        return $this->db->get();
    }

    public function add_unit_ebt_m(){
        $this->db->insert('master_ebt', [
            'nama_plant' => $this->input->post('nama_plant'),
            'plant_id' => $this->input->post('plant_id'),
            'site_id' => $this->input->post('site_id'),
            'commisioning' => $this->input->post('commisioning'),
            'alamat' => $this->input->post('alamat'),
            'time_zone' => $this->input->post('time_zone'),
            'kapasitas' => $this->input->post('kapasitas'),
            'foto' => $this->input->post('foto'),
            'nama_operator' => $this->input->post('nama_operator'),
            'telephone' => $this->input->post('telephone'),
            'email' => $this->input->post('email'),
            'kota' => $this->input->post('kota'),
            'latlong' => $this->input->post('latlong'),
            'status' => $this->input->post('status'),
            'date_created' => $this->input->post('date_created')
            ]);
    }

    public function delete_unit_ebt_m($id){
        $this->db->delete('master_ebt', ['id_master_ebt' => $id]);
    }
}