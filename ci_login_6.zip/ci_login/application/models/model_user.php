<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_user extends CI_Model {

    public function getRole($id){
        $id = $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('user'); 
        $role_view = $this->db->like('role_view','%$id%');
        $pisah = explode('#',$role_view);
        $jumlah = count($pisah);
        for ($i=0; $i <$jumlah ; $i++) { 
            echo $pisah[$i].'<br>';
        }
        return $this->db->get();
    }
    // select role_view from user where $username=session and role_view LIKE %$id% 

    public function getMaster(){
        $this->db->select('*');
        $this->db->from('master_ebt');
        $this->db->join('site', 'master_ebt.site_id=site.site_id');
        return $this->db->get();
    }
    // hapus master
    public function deleteMaster($id){
        $this->db->delete('master_ebt', ['id_master_ebt' => $id]);
    }

    //hapus site
    public function deleteSite($id){
        $this->db->delete('site', ['site_id' => $id]);
    }
    // hapus equipment
    // public function deleteEquipment($id){
    //     $this->db->delete('equipment', ['id' => $id]);
    // }
    // hapus syslog
    public function deleteSyslog($id){
        $this->db->delete('system_logbook', ['id_logbook' => $id]);
    }

    function edit_master($where,$table){                              
        return $this->db->get_where($table,$where);
    }

    function insert_site(){
        $this->db->insert('site', [
            'id_master_site' => $this->input->post('id_master_site'),
            'site_id' => $this->input->post('site_id'),
            'wilayah_kerja' => $this->input->post('wilayah_kerja'),
            'alamat' => $this->input->post('alamat'),
            'telephone' => $this->input->post('telephone'),
            'email' => $this->input->post('email'),
            'kota' => $this->input->post('kota'),
            'status' => $this->input->post('status'),
            'date_created' => $this->input->post('date_created')
            ]);
    }

    function edit_site(){                              
            $id = $this->input->post('site_id');
            $id_master_site = $this->input->post('id_master_site');
            $wilayah_kerja = $this->input->post('wilayah_kerja');
            $alamat = $this->input->post('alamat');
            $telephone = $this->input->post('telephone');
            $email = $this->input->post('email');
            $kota = $this->input->post('kota');
            $status = $this->input->post('status');
            $date_created = $this->input->post('date_created');
            $date_modified = $this->input->post('date_modified');

            $this->db->set('id_master_site', $id_master_site);
            $this->db->set('wilayah_kerja', $wilayah_kerja);
            $this->db->set('alamat', $alamat);
            $this->db->set('telephone', $telephone);
            $this->db->set('email', $email);
            $this->db->set('kota', $kota);
            $this->db->set('status', $status);
            $this->db->set('date_modified', $date_modified);

            $this->db->where('site_id', $id);
            $this->db->where('date_created', $date_created);
            $this->db->update('site');
    }
}