<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class System_logbook_model extends CI_Model {

    public function add_logbook_m()
    {
        $this->db->insert('system_logbook', [
            'id_logbook' => $this->input->post('id_logbook'),
            'type_alarm' => $this->input->post('type_alarm'),
            'time' => $this->input->post('time'),
            'tag_name' => $this->input->post('tag_name'),
            'description' => $this->input->post('description'),
            'sr' => $this->input->post('sr'),
            'wo' => $this->input->post('wo'),
            'date_created' => $this->input->post('date_created'),
            ]);
    }

    public function edit_logbook_m()
    {
        $id = $this->input->post('id_logbook');
            $type_alarm = $this->input->post('type_alarm');
            $time = $this->input->post('time');
            $tag_name = $this->input->post('tag_name');
            $description = $this->input->post('description');
            $sr = $this->input->post('sr');
            $wo = $this->input->post('wo');
            $date_created = $this->input->post('date_created');
            $date_modified = $this->input->post('date_modified');

            $this->db->set('type_alarm', $type_alarm);
            $this->db->set('time', $time);
            $this->db->set('tag_name', $tag_name);
            $this->db->set('description', $description);
            $this->db->set('sr', $sr);
            $this->db->set('wo', $wo);
            $this->db->set('date_modified', $date_modified);

            $this->db->where('id_logbook', $id);
            $this->db->where('date_created', $date_created);
            $this->db->update('system_logbook');
    }

    public function delete_logbook_m($id)
    {
        $this->db->delete('system_logbook', ['id_logbook' => $id]);
    }

    function edit_master($where,$table){                              
        return $this->db->get_where($table,$where);
    }
}