<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">   <meta name="description" content="Tutorial Codeigniter Membuat Hak Akses Menggunakan Jquery dan Mysql">
    <meta name="author" content="Ilmucoding">
    <title>List Category</title>   <!--<link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/sign-in/">-->
    <!-- Bootstrap core CSS -->
    <!--<link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
</head>
<body>
<div class="container mt-5">
<div class="col-md-12 justify-align-center">
    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            List all Category
                            <a href="<?= base_url('auth/logout');?>">Logout</a>
                            <div class="float-right">
                                <!-- <a href="<?= base_url('index.php/auth/logout') ?>" class="btn btn-primary">Logout</a> -->
                                <a style="font-size:10px" href="#" class="satu">Dashboard utama</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <a href="<?= base_url('pages/dashboard_ebt/$hasil');?>">
                             <?php 
                            //pakai opsi/if sama
                            //tapi iki gagelem pidah, dadi misal aku pingin mencet sby sing kepencet sby malang dll alias kabeh
                            //iki nang controller Pages dashboard_ebt
                            //lek jumat goleki aku ojok mari maghrib aku ngaji sek
                            //lek wes ketemu cara misahno ben gak kepencet kabeh iki codingane segment
                            //$this->uri->segment() atau $request->uri->segment()
                            //   foreach ($hasil as $key) {
                            //       echo $key.'<br>'.'<a>'.$this->uri->segment($key);
                            //   }
							
                            for ($i=0; $i <count($hasil) ; $i++) { 
                                $a=$hasil[$i];
                               echo $hasil[$i].'<br>';
                               
                            }
                             ?>
                             </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
</div>
<script>
 
// <?php if($this->session->userdata('kategori') == "admin_ebt"){ ?>
 
//   $(document).ready(function(){
 
//     $(".tiga").remove();
 
//   });
 
<?php } else if($this->session->userdata('kategori') == "view_user"){ ?>
 
  $(document).ready(function(){
 
    $(".tiga").remove();
 
  });
 
<?php } else {}; ?>
 
</script>
</body>
</html>