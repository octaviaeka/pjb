<h1>LOGIN</h1>
<div>
<form class="user" method="post" action="<?= base_url('auth'); ?>">
    <input type="text" class="form-control" id="username" name="username" placeholder="isi username">
    <?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
    <br/>
    <input type="password" class="form-control" id="password" name="password" placeholder="isi password">
    <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
    <br/>
    <button type="submit" class="btn btn-primary">Login</button>
</form>
</div>