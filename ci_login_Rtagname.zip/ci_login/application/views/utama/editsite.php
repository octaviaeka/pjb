<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title><?= $title; ?></title>

  <!-- Custom fonts for this template-->
  <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

                <!-- Divider -->
                    <hr class="sidebar-divider">

                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/dashboard_ebt');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Dashboard EBT</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/plant_overview');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Plant Overview</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/energy_power');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Energy and Power</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/analysis');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Analysis</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/realtime_monitoring');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Realtime Monitoring</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/annual_monitoring');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Annual Monitoring</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/log_monitoring');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Log Monitoring</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/page_visualization');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Page Visualization</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pages/configuration');?>" class="dua">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Configuration</span></a>
                </li>
                <!-- Divider -->
                <hr class="sidebar-divider">

                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('auth/logout'); ?>">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span></a>
                </li>
                
                    <!-- Sidebar Toggler (Sidebar) -->
                    <div class="text-center d-none d-md-inline">
                    <button class="rounded-circle border-0" id="sidebarToggle"></button>
                    </div>
            </ul>
        <!-- End of Sidebar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br/>
          <h1 class="h3 mb-4 text-gray-800">Site</h1>
          <br/>
          <a class="btn btn-secondary" href="<?= base_url('user/admin_utama') ;?>">Back To Dashboard</a>
          <a class="btn btn-primary" href="<?= base_url('utama/site') ;?>">Back To Site</a>

          <div class="row">
                <div class="col-lg">
                <?php foreach($edit as $m) { ?>
                    <?= form_open_multipart('utama/update_site'); ?>
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="id_master_site" name="id_master_site" value="" >
                            <input type="hidden" class="form-control" id="site_id" name="site_id" value="<?php echo $this->uri->segment('3');?>" >
                            <label>Nama Wilayah Kerja</label>
                            <input type="text" class="form-control" id="wilayah_kerja" name="wilayah_kerja" value="<?php echo $m->wilayah_kerja ?>">
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $m->alamat ?>">
                            <?= form_error('menu', '<small class="text-danger pl=3">', '</small>');?>
                        </div>
                        <div class="form-group">
                            <label>Telepon</label>
                            <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo $m->telephone ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo $m->email ?>">
                        </div>
                        <div class="form-group">
                            <label>Kota</label>
                            <input type="text" class="form-control" id="kota" name="kota" value="<?php echo $m->kota ?>">
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <input type="text" class="form-control" id="status" name="status" value="<?php echo $m->status ?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?php echo $m->date_created ?>">
                        </div>
                        <div class="form-group">
                            <input value="<?php echo date("Y-m-d"); ?>" type="hidden" class="form-control" id="date_modified" name="date_modified">
                        </div>

                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        
                    </form>
                    <?php } ?>
                </div>
            </div>
            <br/>
            <br/>
      </div>
      <!-- End of Main Content -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>

    <script>
 
    <?php if($this->session->userdata('kategori') == "admin_ebt"){ ?>
 
    <?php } else if($this->session->userdata('kategori') == "view_user"){ ?>
 
    $(document).ready(function(){
 
    $(".tiga").remove();
 
    });
 
    <?php } else {}; ?>
 
    </script>
</body>

</html>