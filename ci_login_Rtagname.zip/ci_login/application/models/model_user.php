<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_user extends CI_Model {

    public function getRole($id){
        $id = $this->session->userdata('id');
        $this->db->select('*');
        $this->db->from('user'); 
        $role_view = $this->db->like('role_view','%$id%');
        $pisah = explode('#',$role_view);
        $jumlah = count($pisah);
        for ($i=0; $i <$jumlah ; $i++) { 
            echo $pisah[$i].'<br>';
        }
        return $this->db->get();
    }
    // select role_view from user where $username=session and role_view LIKE %$id% 

    public function getMaster(){
        $this->db->select('*');
        $this->db->from('master_ebt');
        $this->db->join('site', 'master_ebt.site_id=site.id');
        return $this->db->get();
    }
    // hapus master
    public function deleteMaster($id){
        $this->db->delete('master_ebt', ['id' => $id]);
    }

    //hapus site
    public function deleteSite($id){
        $this->db->delete('master_site', ['site_id' => $id]);
    }
    // hapus equipment
    // public function deleteEquipment($id){
    //     $this->db->delete('equipment', ['id' => $id]);
    // }
    // hapus syslog
    public function deleteSyslog($id){
        $this->db->delete('system_logbook', ['id_logbook' => $id]);
    }

    function edit_master($where,$table){                              
        return $this->db->get_where($table,$where);
    }
}